#include <stdio.h>
#include <stdlib.h> //exit()

int opc;

int dato;
#define MAX 5 // Tamano maximo de la Cola Circular
int colacirc[MAX]; // Declaracion del arreglo para almacenar la Cola Circular
int frente, fin; // Inidicadores del inicio y final de la Cola Circular

void insertar();
void Eliminar();
void Mostrar();

int main (int argc , char * argv []){
    //Cola circular inicializada!
    frente=-1; fin=-1;
do {
      printf("\n");
      printf("Menu COLA CIRCULAR: \n");
      printf("1. Insertar\n");
      printf("2. Eliminar \n");
      printf("3. mostrar \n");
      printf("4. Salir \n");
      printf("Escoja opción:");
      scanf("%d", &opc);
    
    switch (opc) {
      case 1:
            insertar();
        break;
      case 2:
            Eliminar();
        break;
      case 3:
        Mostrar();
        break;
    }//switch
  } while( opc != 4);
  
  return 0;
} /* fin de la función main */

void insertar(){
    printf("\n Dato a insertar?: ");
    scanf("%d" , &dato);
    if((fin==MAX-1 && frente==0) || (fin+1==frente)) {
            printf("\nCola Circular llena !!!");
            return;
    }
    if(fin==MAX-1 && frente!=0) 
        fin=0; 
    else fin++;
    colacirc[fin]=dato;
    if(frente==-1) 
        frente=0;
}

void Eliminar() {
        printf("\n\n ELIMINAR DATO");
        if(frente==-1) {
            printf("\nCola Circular vacia !!!");
            return;
        }
        printf("\nDato eliminado = %d",colacirc[frente]);
        if(frente==fin) {
            frente=-1; fin=-1;
            return;
        }
        frente++;
        if(frente==MAX) 
            frente=0;
        //else frente++; 
}

void Mostrar() {
        int i=0;
        printf("\n\nMOSTRAR COLA CIRCULAR");
        if(frente==-1) {
            printf("\nCola Circular vacia !!!");
        }
        else {
            i=frente;
            do {
                printf("\n colacirc[%d]=%d",i,colacirc[i]);
                i++;
                if(i==MAX && frente>fin) i=0; // Reiniciar en cero (dar la vuelta)
            }while(i!=fin+1);
        }

        printf("\nfrente=%d",frente);
        printf("\nfin=%d",fin);
        printf("\nmax=%d",MAX);
}
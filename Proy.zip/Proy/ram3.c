#include <math.h>
#include <stdio.h>
#include <stdlib.h> //exit()
#include <string.h>// strcat()
/*Var globales: */
#define TAM 10 //num bloques de la ram
#define TAM2 30 //num bloques de almacenaje
int dato;//FIFO y Reloj
char almacenamiento [TAM2][40];
char ram [TAM][40];
#define INTT 2
#define FLOATT 4
#define DOUBLEE 8
#define CHARTT 1
int datoTotal=0;
int opc;
int tamBloque=2;
int numbloques,residuo;
int tamRestante; //tam restante de la ram
int cont1,contIteration,i,j,k,vacios;
char name [10];
int l,rblocks;
int bandnull;

int bandera=0,tam;int contadorDato=0, bandera2;
  /*Reloj */
#define MAX 5 // Tamano maximo de la Cola Circular
int colacirc[MAX]; // Declaracion del arreglo para almacenar la Cola Circular
int frente, fin; // Inidicadores del inicio y final de la Cola Circular

/*Cola:*/
struct pagina {
  int tamano;
  int id;
  char *nombre;
  struct pagina *siguiente;
};

typedef struct pagina Nodo;

Nodo *final;
Nodo *inicio;

/*Declaracion:*/
/*Cola:*/
char* getPtrNom();
int getId();
int isEmpty();
int menu();
void clearBuffer();
void dequeue();
void enqueue();
void isEmptyWrap();

void insertar(Nodo *temporal); 
void eliminarRAM();
void menuFifo();
  /*Reloj*/
void menuReloj();
void insertarR();
void EliminarR();
void MostrarR();

int main (int argc , char * argv [])
{
  /*int i;
  final = inicio = 0;
  
  //limpiando vector ram
  for(i=0;i<TAM;i++){
    strcpy(ram[i],"-");
  }
  //limpiando vector almacenamiento
  for(i=0;i<TAM2;i++){
    strcpy(almacenamiento[i],"-");
  }*/

  do {
      printf("\n");
      printf("Menu: \n");
      printf("1. FIFO\n");
      printf("2. RELOJ \n");
      printf("3. ALEATORIO \n");
      printf("4. Salir \n");
      printf("Escoja opción:");
      scanf("%d", &opc);
    
    switch (opc) {
      case 1:
        menuFifo();
        break;
      case 2:
        menuReloj();
        break;
      case 3:
        
        break;
    }//switch
  } while( opc != 4);
  
  return 0;
} /* fin de la función main */

/*Definicion: */
void menuFifo()
{
  int i;
  final = inicio = 0;
  
  //limpiando vector ram
  for(i=0;i<TAM;i++){
    strcpy(ram[i],"-");
  }
  //limpiando vector almacenamiento
  for(i=0;i<TAM2;i++){
    strcpy(almacenamiento[i],"-");
  }

  do {
      printf("\n");
      printf("Menu: \n");
      printf("1. Insertar\n");
      printf("2. Desencolar \n");
      printf("3. Eliminar de RAM \n");
      printf("4. Salir \n");
      printf("Escoja opción:");
      scanf("%d", &opc);
    
    switch (opc) {
      case 1:
        enqueue();
        break;
      case 2:
        dequeue();
        break;
      case 3:
        eliminarRAM();
        break;
    }//switch
  } while( opc != 4);
} /* fin menuCola*/

/*METODOS COLA: */
int getTamano(){
  return (rand () % 11);
}

int getId() {
  int num;
  printf("Ingrese el ID: ");
  scanf("%d" , &num);
  return num;
}

// retorna un nuevo puntero a un arreglo
char* getPtrNom() {
  char d,*newAr;

  int i = 0;

  newAr = (char*) malloc(sizeof(char)*100);

  printf("Ingrese el nombre: ");

  while((d = getchar()) != EOF && d != '\n') {
    newAr[i++] = d;
  }

  return newAr;
}

// imprime el primer valor ingresado
// el penultimo valor es el nuevo inicio
// el primer valor es borrado de la lista
void dequeue() {
  Nodo *actual,
       *temporal;

  //printf("\tdequeue()\n");
  //printf("nfin: %p\nini: %p\n", final, inicio);
  clearBuffer();

  bandera=1;

  if (isEmpty()) {
    printf("meter algo en la cola...");
  } else {
    if (final == inicio) { // si solo hay 1 nodo
      //printf("1nodo\t\tnfin: %p\nini: %p\n", final, inicio);
      printf("%d | %s | %d \n", final->id, final->nombre, final->tamano);
      insertar(final);
      if(bandera==1){
      //free(final); // liberamos la memoria que uso el nodo
      //free(inicio); // liberamos la memoria que uso el nodo
      final = inicio = 0; // dejamos los punteros en null
      }else
        printf("No eliminado");
    } else { // si hay mas de 1 nodo
      if(bandera==1){
      //printf("1+nodo\t\tnfin: %p\nini: %p\n", final, inicio);
      actual = final;
      
      while (actual != inicio) { // recorra la cola y quede en el penultimo
        temporal = actual; // temporal guarda la direccion del penultimo
        actual = temporal->siguiente;
      } insertar(actual);
      printf("%d | %s | %d \n", inicio->id, inicio->nombre, inicio->tamano); // imprimimos el ultimo nodo
      //free(inicio); // liberamos la memoria usada por el ultimo nodo
      inicio = temporal; // el penultimo es ahora el ultimo
    }//bandera
    }
  }//ELSE
}//FIN METODO

// agrega un nodo nuevo al final de la cola
void enqueue() {
  Nodo *nodoNuevo,
       *temporal;

  nodoNuevo = (Nodo*) malloc(sizeof(Nodo));
  clearBuffer();

  nodoNuevo->nombre = getPtrNom();
  nodoNuevo->id = getId();
  nodoNuevo->tamano = getTamano();

  //printf("\n\tenqueue()\n");
  if (isEmpty()) { // si la cola esta vacia
    final = nodoNuevo; // el nodo toma el primer
    inicio = nodoNuevo; // y el ultimo lugar
  } else { // si hay al menos 1 nodo
    temporal = final; // almacenamos el ultimo nodo agregado
    final = nodoNuevo; // el nodoNuevo toma el primer lugar
    final->siguiente = temporal; // apuntando al nodo que estaba en primer lugar
  }
  //printf("nvo: %p\nfin: %p\nini: %p\n", nodoNuevo, final, inicio);
  clearBuffer();
}

int isEmpty() {
  if (!final) {
    return 1;
  } else {
    return 0;
  }
}

// cuando se manejan menus que tienen breaklines, se ocupa limpiar el buffer
// antes de empezar a leer caracteres
void clearBuffer() {
  while(getchar() != '\n')
    ;
}

/*RAM*/
void insertar(Nodo *temporal){
  int dato;
  numbloques=0;
  datoTotal=temporal->tamano;
      
  printf("datoTotal: %d",datoTotal);
  
  //BLOQUES DE BYTES:
  numbloques=(int)(datoTotal/tamBloque);
  residuo=datoTotal%tamBloque;
  if(residuo!=0){
    numbloques=numbloques+1;
  }

  //VALIDACION IF(NUMBLOQUES DEL ARREGLO > NUM DE BLOQUES)
  if(numbloques==0){
    numbloques=1;
  }
  if(numbloques > TAM){
    printf(" \n Dato muy grande, revisa el num de bloques");
    numbloques=0;
    datoTotal=0;
  }

  printf("\n Num de bloques que usara: %d",numbloques);

  sprintf(name, "%d", numbloques); //castear

  tamRestante=TAM-numbloques;
  bandnull=0;//cero no puede guardar
  for(i=0; i<=tamRestante; i++){
    cont1=0;
    contIteration=i+numbloques;
    for(j=i;j<contIteration;j++){
      if((strcmp(ram[j],"-"))==0){
        cont1=cont1+1;
      }
    }
    if(cont1==numbloques){//espacios libres
      bandnull=1;//puede guardar
      fflush(stdin);//limpiar buffer
      for(k=i;k<contIteration;k++){
        strcpy(ram[k],name);//insertar datos
      }
      i=tamRestante+1;
    }
  }

  if(bandnull==0){//ram llena, desplaza...
    vacios=0;
    for(j=0;j<TAM;j++){//busqueda de bloques vacios
      if((strcmp(ram[j],"-"))==0){
        vacios=vacios+1;
      }
    }
    if(vacios==0){//lleno
      printf("\n No hay espacio");
      bandera=0;
    }else if(vacios<numbloques){//se desplazo y no alcanza
      printf("\n No hay espacio aunque desplaces");
      bandera=0;
    }else{
      //alcanza, puede desplazar
      rblocks=0;
      l=0;
      do{
        //recorrer espacios vacios
        if((strcmp(ram[l ],"-"))==0){
          for(i=l+1;i<TAM;i++){
            strcpy(ram[i-1],ram[i]);
          }
          rblocks=rblocks+1;
          strcpy(ram[TAM-rblocks],"-");

        }else{
          l=l+1;
        }
      }while(l <(TAM-rblocks));

      printf("\n Desplazando: ");
      for(l=0;l<TAM;l++){
        printf("\n %d %s",l,ram[l]);
      }
    }
  }

  for(int i=0; i<TAM; i++){
    printf(" \n RAM: %s",ram[i]);
  }
  //datoTotal=0;
  printf("\n");    
}//FIN INSERTAR

void eliminarRAM(){
  int dato,z;
  char datostring [10];
  int pos;
  

  dato=atoi(ram[0]);
  printf("Dato a eliminar: %d",dato);
  sprintf(datostring, "%d", dato); //castear

	for(i=0;i<TAM;i++){//limpiando vector
	  if ( (strcmp(ram[i],datostring) ) == 0){
		  strcpy(ram[i],"-");
          contadorDato+=1;
		}
	}
	
	for(z=0;z<TAM;z++){//mostrando vector
		printf("\n [%d] %s",z,ram[z]);
  }

  do{
    //recorrer espacios vacios
    if((strcmp(ram[l ],"-"))==0){
      for(i=l+1;i<TAM;i++){
        strcpy(ram[i-1],ram[i]);
      }
      rblocks=rblocks+1;
      strcpy(ram[TAM-rblocks],"-");
    }else{
      l=l+1;
    }
  }while(l <(TAM-rblocks));

  printf("\n Desplazando: ");
  for(l=0;l<TAM;l++){
    printf("\n %d %s",l,ram[l]);
  }
 
 
 /*Insertar a almacenamiento:*/
 	tam=TAM2-contadorDato;
	bandera2=0;//cero no puede guardar
  for(i=0; i<=tam; i++){
    cont1=0;
    contIteration=i+contadorDato;
    for(j=i;j<contIteration;j++){
      if((strcmp(almacenamiento[j],"-"))==0){
        cont1=cont1+1;
        printf("\ncont 1: %d",cont1);
      }
    }
    printf("\ncontadorDato:%d",contadorDato);
    if(cont1==atoi(datostring)){//espacios libres
      bandera2=1;//puede guardar
      fflush(stdin);//limpiar buffer
      for(k=i;k<contIteration;k++){
        strcpy(almacenamiento[k],datostring);//insertar datos
      }
      i=tam+1;
    }
  }
  
  printf("\n Almacenamiento");
  for(i=0; i<TAM2; i++){
            printf("%s",almacenamiento[i]);
    }
}

/*--------------RELOJ------------------*/
void menuReloj(){
    //Cola circular inicializada!
    frente=-1; fin=-1;
do {
      printf("\n");
      printf("Menu COLA CIRCULAR: \n");
      printf("1. Insertar\n");
      printf("2. Eliminar \n");
      printf("3. mostrar \n");
      printf("4. Salir \n");
      printf("Escoja opción:");
      scanf("%d", &opc);
    
    switch (opc) {
      case 1:
            insertarR();
        break;
      case 2:
            EliminarR();
        break;
      case 3:
        MostrarR();
        break;
    }//switch
  } while( opc != 4);
  
} /* fin menuReloj */

void insertarR(){
    printf("\n Dato a insertar?: ");
    scanf("%d" , &dato);
    if((fin==MAX-1 && frente==0) || (fin+1==frente)) {
            printf("\nCola Circular llena !!!");
            return;
    }
    if(fin==MAX-1 && frente!=0) 
        fin=0; 
    else fin++;
    colacirc[fin]=dato;
    /* for(i = 0; i < MAX; i++){//add
      colacirc[i]=rand() % 2;//mod
      fin++;//add
    }*/
    if(frente==-1) 
        frente=0;
}

void EliminarR() {
        printf("\n\n ELIMINAR DATO");
        if(frente==-1) {
            printf("\nCola Circular vacia !!!");
            return;
        }
        printf("\nDato eliminado = %d",colacirc[frente]);
        if(frente==fin) {
            frente=-1; fin=-1;
            return;
        }
        frente++;
        if(frente==MAX) 
            frente=0;
        //else frente++; 
}

void MostrarR() {
        int i=0;
        printf("\n\nMOSTRAR COLA CIRCULAR");
        if(frente==-1) {
            printf("\nCola Circular vacia !!!");
        }
        else {
            i=frente;
            do {
                printf("\n colacirc[%d]=%d",i,colacirc[i]);
                i++;
                if(i==MAX && frente>fin) i=0; // Reiniciar en cero (dar la vuelta)
            }while(i!=fin+1);
        }

        printf("\nfrente=%d",frente);
        printf("\nfin=%d",fin);
        printf("\nmax=%d",MAX);
}

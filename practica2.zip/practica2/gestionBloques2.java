import java.util.Scanner;
import java.util.*;

public class gestionBloques2{
  static String nombre;
  static double tamano;
  static final int TAM = 10;//tamaño arreglo
  static final int BYTES = 3;
  static int cont=0;
  static ArrayList<String> arreglo = new ArrayList<String>(TAM);
  static ArrayList<String> arregloDos = new ArrayList<String>(TAM);
  static int getIndice=0;
  static int setIndice=0;

  public static void crearArchivo(){
    Scanner lectura = new Scanner(System.in);
    System.out.println("Nombre del archivo:");
    nombre=lectura.nextLine();
    System.out.println("Tamaño:");
    tamano=lectura.nextDouble();
  }
  public static void contigua(){
    int residuo,cociente,bloques,nuevoBloque,aux;

    residuo=(int)tamano%BYTES;
    cociente=(int)tamano/BYTES;

    //System.out.println("indice 1:"+setIndice);

    if (residuo == 0) {
      bloques=cociente;
      if(bloques<=TAM){
        do{
        for (int i=0;i<bloques ;i++ ) {
          if(arreglo.get(i).equals(" "));
          arreglo.set(i,nombre);
          cont+=1;
          setIndice=i;
        }
      }while(cont == bloques);
        setIndice=setIndice+1;

      }else{
        System.out.println("No hay espacio...");
      }
    }else{
      nuevoBloque=cociente+residuo;
      if(nuevoBloque<=TAM){
        do{
        for (int i=0;i<nuevoBloque ;i++ ) {
          if(arreglo.get(i).equals(" "));
          arreglo.set(i,nombre);
          cont+=1;
          setIndice=i;
        }
      }while(cont == nuevoBloque);
        setIndice=setIndice+1;
      }else{
        System.out.println("No hay espacio...");
      }
    }
    //System.out.println("indice 1:"+setIndice);

//imprimir
    for (int i=0;i<arreglo.size() ;i++ ) {
      System.out.println("Arreglo["+i+"]:"+arreglo.get(i));
    }
    System.out.println(arreglo.size()); //cuántos elementos tiene un ArrayList,
    System.out.println(cont);

    System.out.println("¿Quieres revisar espacios? si/no");
    Scanner lectura = new Scanner(System.in);
    if(lectura.nextLine().equals("si")){
      for (int i=0;i<arreglo.size() ;i++ ) {
        if(arreglo.get(i).equals("null")){//si es null
          cont+=1;//contador de nulls
        }else{
          arregloDos.add(arreglo.get(i));//add nombres
        }
      }
      for (int i=0;i<cont;i++ ) {
          arregloDos.add("null");
      }
      arreglo.clear();
      for(int i=0; i<TAM;i++){
          arreglo.add(arregloDos.get(i));
      }

      for (int i=0;i<arreglo.size();i++ ) {
        System.out.println("check arreglo["+i+"]:"+arreglo.get(i));
      }


    }else System.out.println("noo");
  }//fin continua

  public static void eliminar(){
    String nombreEliminar;

    Scanner lectura = new Scanner(System.in);
    System.out.println("Nombre del archivo a eliminar:");
    nombreEliminar=lectura.nextLine();

    for (int i=0;i<arreglo.size();i++) {
      String dato = arreglo.get(i).toString();

      if (dato.equals(nombreEliminar)) {
        arreglo.set(i,null);
      }else System.out.println("No existe");
    }

    for (int j=0;j<arreglo.size();j++ ) {
      System.out.println("Arr["+j+"]"+arreglo.get(j));
    }

  }

  public  static void inicializar(){
    for (int i=0;i<TAM ;i++) {
      arreglo.add("null");
    }

    for (int i=0;i<TAM ;i++) {
      System.out.println("Inicializacion["+i+"]:"+arreglo.get(i));
    }
  }

  public static void main(String[] args) {
    int opc;

    do {
      System.out.println(" ");
      System.out.println("MENU: ");
      System.out.println("1.Crear archivo");
      System.out.println("2.Asignacion contigua");
      System.out.println("3.Fragmentada");
      System.out.println("4.Eliminar archivo");
      System.out.println("5.Salir");
      System.out.println("6.Iniciar");
      System.out.println("Seleccione opción");
      Scanner lectura = new Scanner(System.in);
      opc= lectura.nextInt();

      switch (opc) {
        case 1:
          gestionBloques2.crearArchivo();
          break;
        case 2:
          gestionBloques2.contigua();
          break;
        case 4:
          gestionBloques2.eliminar();
          break;
        case 6:
          gestionBloques2.inicializar();
          break;
        default:
      }
    } while ( opc!= 5);
  }
}

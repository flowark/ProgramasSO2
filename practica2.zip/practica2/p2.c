/* 
Programa 2:
Materia:SO2
Fecha:28/05/19
Descripcion:Simulacion de asignacion secuencial y no secuencial
Alumna:Ana Paola Ortega de la Barrera 201315861
cd Documentos/so2/p2
gcc p2.c -o p2
 */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>// strcat
#define MAX_STRING_SIZE 40


int main()
{
    int n, opcion,opcion2,nb,tb;
	int i,j,x,z,k,m;
    int ap1=0;
    int tamdoc,numbloq;
    int upa;//ultima posicion caso uno apuntador
    int conti,cont1;
    double divent;//cuantos bloques ocupa
    int ix;
    int bvacios;
    int vacios;
    int repetido;
    int rb;
    int contnb;
    int total;
    int pos;

	
    printf( "\n   Proporciona Numero de bloques:" );
    scanf( "%d", &nb );
    printf( "\n   Proporciona Tamaño de bloques:" );
    scanf( "%d", &tb );
    char arr[nb][40];//vector
    char arr2[nb][40];//vector
    for(i=0;i<nb;i++){//limpiando vector
	//arr[i]="-";
        strcpy(arr[i],"-");
    }
    printf( "\n   Tam bloq:%d bytes Num Total de Bloques:%d",tb,nb);
    for(i=0;i<nb;i++){//mostrando vector
       printf("\n%d %s",i,arr[i]);
    }

    do
    {
	printf( "\n   Como deseas insertar:" );
        printf( "\n   1. Contigua." );
        printf( "\n   2. Fragmentada." );
        printf( "\n   3. Eliminar." );
        printf( "\n   4. Desfragmentar." );
        printf( "\n   5. Desplazar." );
        printf( "\n   6. Salir." );

        /* Filtramos la opción elegida por el usuario */
        do
        {
            printf( "\n   Introduzca opcion (1-6): ");
            scanf( "%d", &opcion );

        } while ( opcion < 1 || opcion > 6 );
        /* La opción sólo puede ser 1, 2, ,3, 4 , 5 o 6*/

        switch ( opcion )
        {
            case 1: printf( "\n   1.Introduzca nombre del archivo: " );
//..........................
		    
                    numbloq=0;
                    char nombre[30];
                    fflush( stdin );
		    scanf("%s", nombre);
                    repetido=0;
	            for(i=0;i<nb;i++){//limpiando vector
		         if ( strcmp(arr[i],nombre) == 0){
			      printf("\n**El archivo ya existe,si quieres actualizar elimina e inserta de nuevo");
                              repetido=1;
                              break;
	                 }
	            }
                    if(repetido==1){
                    	break; 
                    }
                    printf( "\n   1.Introduzca tamano del archivo bytes:" );
                    fflush( stdin );
                    scanf("%d", &tamdoc);
                    numbloq=(int)(tamdoc/tb);
                    divent=tamdoc%tb;
                    if (divent != 0){
                   	 numbloq=numbloq+1;
                    }
                    printf( "\n   Numero de bloques que ocupara:%d",numbloq);

        //validar si numbloq es mas grande que nb
        if (numbloq > nb){
              printf("\n**El archivo es demasiado grande,sobrepasa el numero de bloques");
              break;
        }
        if (numbloq == 0){
              numbloq=1;
        }

	upa=nb-numbloq;//valor maximo del apuntador
        bvacios=0;//bandera 0=No pude guardar 1=Si pude guardar
        for(i=0;i<=upa;i++){//recorriendo posiciones para primer bloque
		cont1=0;
                conti=i+numbloq;
                for(j=i;j<conti;j++){//recorriendo posiciones buscando un grupo de bloques vacios
                        if ( (strcmp(arr[j],"-") ) == 0){
				cont1=cont1+1;
                         }
                }
                if (cont1 == numbloq){//si ya encontre un espacio donde meterlo
                    bvacios=1;//Activo la bandera
                    //printf("\ncont1=%d i=%d",cont1,i);
                    fflush( stdin );
		    for(x=i;x<conti;x++){
                        strcpy(arr[x],nombre);
                        //printf("\n*%d %s",x,arr[x]);
                    }
                    i=upa+1;
                }
        }

        if (bvacios == 0){//no pudo guardarse a la primera,se lleno,hay espacio pero falta desplazar, los espacios no alcanzan ni desplazando
                vacios=0;
                for(j=0;j<nb;j++){//recorriendo posiciones buscando bloques vacios
                        if ( (strcmp(arr[j],"-") ) == 0){
				vacios=vacios+1;
                         }
                }
                if (vacios == 0){//esta lleno
                	printf("\n**Todos los bloques estan ocupados...intenta eliminar");
                }else if (vacios < numbloq){//no alcanza aunque desplace
                        printf("\n**No hay suficientes bloques aunque desplaces...intenta eliminar");
                }else{//si alcanza si desplazo
//**********************************Otro menu desplazamiento
		    do
		    {
			printf( "\n   Que deseas hacer:" );
			printf( "\n   1. Desplazar." );
			printf( "\n   2. Salir." );

			/* Filtramos la opción elegida por el usuario */
			do
			{
			    printf( "\n   Introduzca opcion2 (1-2): ");
			    scanf( "%d", &opcion2 );

			} while ( opcion2 < 1 || opcion2 > 2 );
			/* La opción sólo puede ser 1,o 2 */

			switch ( opcion2 )
			{
			    case 1:
//******************************
				   rb=0;
				   z=0;
				   do{//recorrer espacios vacios
					    if((strcmp(arr[z],"-"))==0){
					       for(i=z+1;i<nb;i++){//mostrando vector
					       	   strcpy(arr[i-1],arr[i]);
					       }
					       rb=rb+1;
					       strcpy(arr[nb-rb],"-");
					    }else{
						z=z+1;
						//printf("\n%d",z);
					    }
				   }while (z<(nb-rb));

				   
				   printf( "\nDesplazando: ");
				   for(z=0;z<nb;z++){//mostrando vector
					      printf("\n%d %s",z,arr[z]);
				   }
   

//**********************************
				    break;
			 }

		    } while ( opcion2 != 2 );

//**********************************
     
                }


        }

	for(z=0;z<nb;z++){//mostrando vector
	      printf("\n%d %s",z,arr[z]);
        }


		  
//............................
		    break;

            case 2: printf( "\n   2.Introduzca nombre del archivo: " );
//............................
		    numbloq=0;
                    char nombre2[30];
                    fflush( stdin );
		    scanf("%s", nombre2);

//////////////////
                    repetido=0;
	            for(i=0;i<nb;i++){//limpiando vector
		         if ( strcmp(arr[i],nombre2) == 0){
			      printf("\n**El archivo ya existe,si quieres actualizar elimina e inserta de nuevo");
                              repetido=1;
                              break;
	                 }
	            }
                    if(repetido==1){
                    	break; 
                    }
/////////////////
                    printf( "\n   1.Introduzca tamano del archivo bytes:" );
                    fflush( stdin );
                    scanf("%d", &tamdoc);
                    numbloq=(int)(tamdoc/tb);
                    divent=tamdoc%tb;
                    if (divent != 0){
                   	 numbloq=numbloq+1;
                    }
                    printf( "\n   Numero de bloques que ocupara:%d",numbloq);

        //validar si numbloq es mas grande que nb
        if (numbloq > nb){
              printf("\n**El archivo es demasiado grande,sobrepasa el numero de bloques");
              break;
        }
        if (numbloq == 0){
              numbloq=1;
        }


                vacios=0;
                for(j=0;j<nb;j++){//recorriendo posiciones buscando bloques vacios
                        if ( (strcmp(arr[j],"-") ) == 0){
				vacios=vacios+1;
                         }
                }
                if (vacios == 0){//esta lleno
                	printf("\n**Todos los bloques estan ocupados...intenta eliminar");
                }else if (vacios < numbloq){//no alcanza aunque desfragmente
                        printf("\n**No hay suficientes bloques...intenta eliminar");
                }else{//si alcanza los agrego al arreglo

//...................
		        cont1=0;
			for(i=0;i<nb;i++){//recorriendo posiciones para primer bloque
				if ( (strcmp(arr[i],"-") ) == 0){
					cont1=cont1+1;
                                        strcpy(arr[i],nombre2);
				}
				if (cont1 == numbloq){//si ya inserte todos
				    i=nb+1;//termino el ciclo
				}
			}
//.......................
     
                }


        

	for(z=0;z<nb;z++){//mostrando vector
	      printf("\n%d %s",z,arr[z]);
        }

//............................                    
	    break;

            case 3: printf( "\n   2.Introduzca nombre del archivo a eliminar: " );
//............................
		            char nombre3[30];
                            fflush( stdin );
		            scanf("%s", nombre3);
			    for(i=0;i<nb;i++){//limpiando vector
			         if ( (strcmp(arr[i],nombre3) ) == 0){
				      strcpy(arr[i],"-");
		                 }
			    }
			    for(z=0;z<nb;z++){//mostrando vector
				    printf("\n%d %s",z,arr[z]);
			    }
//............................                    
	    break;
            case 4:
//**********************************Otro menu desfragmentar

/*para pruebas
strcpy(arr[0],"a");
strcpy(arr[1],"b");
strcpy(arr[2],"c");
strcpy(arr[3],"b");
strcpy(arr[4],"a");
strcpy(arr[5],"g");
strcpy(arr[6],"-");
strcpy(arr[7],"a");
strcpy(arr[8],"-");
strcpy(arr[9],"b");

*/
//---------------Desplazando  
    
rb=0;
z=0;
do{//recorrer espacios vacios
    if((strcmp(arr[z],"-"))==0){
       for(i=z+1;i<nb;i++){//mostrando vector
       	   strcpy(arr[i-1],arr[i]);
       }
       rb=rb+1;
       strcpy(arr[nb-rb],"-");
    }else{
	z=z+1;
	//printf("\n%d",z);
    }
}while (z<(nb-rb));



for(i=0;i<nb;i++){//copiando arreglo
	strcpy(arr2[i],arr[i]);
}


pos=0;
for(i=0;i<nb;i++){//recorriendo todo el arreglo
        contnb=0;
	if((strcmp(arr2[i],"-"))!=0){
	       for(j=i+1;j<nb;j++){//busca en todo el arreglo cuantos hay
			if((strcmp(arr2[i],arr2[j]))==0){
				contnb=contnb+1;
		                strcpy(arr2[j],"-");
			}      
	  
	      }
              if(contnb==0){
	         contnb=1;
              }else{
                 contnb=contnb+1;
              }
              //printf("\ncontando:%s %d",arr2[i],contnb);
              for(k=pos;k<pos+contnb;k++){
	          strcpy(arr[k],arr2[i]);
              }
              pos=pos+contnb;
 
	}    
}

   puts("\nDesfragmentado:");
   for(z=0;z<nb;z++){//mostrando vector
	      printf("\n%d %s",z,arr[z]);
   }


            break;

            case 5:
		   rb=0;
		   z=0;
		   do{//recorrer espacios vacios
			    if((strcmp(arr[z],"-"))==0){
			       for(i=z+1;i<nb;i++){//mostrando vector
			       	   strcpy(arr[i-1],arr[i]);
			       }
			       rb=rb+1;
			       strcpy(arr[nb-rb],"-");
			    }else{
				z=z+1;
				//printf("\n%d",z);
			    }
		   }while (z<(nb-rb));

		   
		   puts("\nDesplazando:");
		   for(z=0;z<nb;z++){//mostrando vector
			      printf("\n%d %s",z,arr[z]);
		   }
		   

            break;
         }

    } while ( opcion != 6 );

    return 0;
}







#include <math.h>
#include <stdio.h>
#include <stdlib.h> //exit()
#include <string.h>// strcat()

#define TAM 10 //num bloques de la ram
#define TAM2 10 //num bloques de almacenaje
int dato;
char almacenamiento [TAM2][40];
char ram [TAM][40];
#define INTT 2
#define FLOATT 4
#define DOUBLEE 8
#define CHARTT 1
int datoTotal=0;
int opc;
int tamBloque=2;
int numbloques,residuo;
int tamRestante; //tam restante de la ram
int cont1,contIteration,i,j,k,vacios;
char name [10];
int l,rblocks;
int bandnull;

void insertar(){
  int dato;
  numbloques=0;

  do {
      printf("\n");
      printf("¿Tipo de dato a insertar? \n");
      printf("1. Int\n");
      printf("2. Float \n");
      printf("3. Double \n");
      printf("4. Chart \n");
      printf("6. Salir \n");
      printf("Escoja opción:");
      scanf("%d", &opc);
    
    switch (opc) {
      case 1: 
        printf("No datos a insertar:");
        scanf("%d",&dato);
        datoTotal=datoTotal+(dato*INTT);
        break;
      case 2:
        printf("No datos a insertar:");
        scanf("%d",&dato);
        datoTotal=datoTotal+(dato*FLOATT);
        break;
      case 3:
        printf("No datos a insertar:");
        scanf("%d",&dato);
        datoTotal=datoTotal+(dato*DOUBLEE);
        break;
      case 4:
        printf("No datos a insertar:");
        scanf("%d",&dato);
        datoTotal=datoTotal+(dato*CHARTT);
        break;
    }//switch
  } while( opc != 6);
  printf("datoTotal: %d",datoTotal);
  
  //BLOQUES DE BYTES:
  numbloques=(int)(datoTotal/tamBloque);
  residuo=datoTotal%tamBloque;
  if(residuo!=0){
    numbloques=numbloques+1;
  }

  //VALIDACION IF(NUMBLOQUES DEL ARREGLO > NUM DE BLOQUES)
  if(numbloques==0){
    numbloques=1;
  }
  if(numbloques > TAM){
    printf(" \n Dato muy grande, revisa el num de bloques");
    numbloques=0;
    datoTotal=0;
  }

  printf("\n Num de bloques que usara: %d",numbloques);

  sprintf(name, "%d", numbloques);

  tamRestante=TAM-numbloques;
  bandnull=0;//cero no puede guardar
  for(i=0; i<=tamRestante; i++){
    cont1=0;
    contIteration=i+numbloques;
    for(j=i;j<contIteration;j++){
      if((strcmp(ram[j],"-"))==0){
        cont1=cont1+1;
      }
    }
    if(cont1==numbloques){//espacios libres
      bandnull=1;//puede guardar
      fflush(stdin);//limpiar buffer
      for(k=i;k<contIteration;k++){
        strcpy(ram[k],name);//insertar datos
      }
      i=tamRestante+1;
    }
  }

  if(bandnull==0){//ram llena, desplaza...
    vacios=0;
    for(j=0;j<TAM;j++){//busqueda de bloques vacios
      if((strcmp(ram[j],"-"))==0){
        vacios=vacios+1;
      }
    }
    if(vacios==0){//lleno
      printf("\n No hay espacio");
    }else if(vacios<numbloques){//se desplazo y no alcanza
      printf("\n No hay espacio aunque desplaces");
    }else{
      //alcanza, puede desplazar
      rblocks=0;
      l=0;
      do{
        //recorrer espacios vacios
        if((strcmp(ram[l ],"-"))==0){
          for(i=l+1;i<TAM;i++){
            strcpy(ram[i-1],ram[i]);
          }
          rblocks=rblocks+1;
          strcpy(ram[TAM-rblocks],"-");

        }else{
          l=l+1;
        }
      }while(l <(TAM-rblocks));

      printf("\n Desplazando: ");
      for(l=0;l<TAM;l++){
        printf("\n %d %s",l,ram[l]);
      }
    }
  }

  for(int i=0; i<TAM; i++){
    printf(" \n RAM: %s",ram[i]);
  }
  datoTotal=0;
  printf("\n");    
}//FIN INSERTAR

int main (int argc , char * argv [])
{
  int i;
  
  //limpiando vector ram
  for(i=0;i<TAM;i++){
    strcpy(ram[i],"-");
  }

  do {
      printf("\n");
      printf("Menu: \n");
      printf("1. Insertar\n");
      printf("2. Eliminar \n");
      printf("3. Recuperar \n");
      printf("4. Salir \n");
      printf("Escoja opción:");
      scanf("%d", &opc);
    
    switch (opc) {
      case 1:
        insertar();
        break;
      case 2:
        break;
      case 3:
        break;
    }//switch
  } while( opc != 4);
  
  return 0;
} /* fin de la función main */